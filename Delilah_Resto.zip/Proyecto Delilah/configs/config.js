module.exports = {
    secret_token: "clave*/%124156.j455"
}