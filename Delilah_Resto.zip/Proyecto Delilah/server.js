const express = require('express');
const server = express();
const bodyParser = require('body-parser');
const { db, Sequelize } = require('./conexionBD')

server.use(bodyParser.json())

const rutasPedidos = require('./src/rutas/pedidos')
const rutasUsuarios = require('./src/rutas/usuarios')
const rutasProductos = require('./src/rutas/productos')

server.use('/pedidos', rutasPedidos)
server.use('/usuarios', rutasUsuarios)
server.use('/productos', rutasProductos)


server.listen(5500, () => console.log("Servidor en puerto 5500, iniciado"))