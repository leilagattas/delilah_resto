const router = require('express').Router();
const { db, Sequelize } = require('../../conexionBD');
const autorizarUsuario = require('../middleware/autorizacion')


//OBTENER TODOS PRODUCTOS
router.get('', (req, res) => {
    db.query('SELECT ID_Producto, Nombre, Precio, URL_Imagen FROM productos WHERE Stock > 0')
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results)
            res.status(200).send({
                mensaje: "Listado de productos",
                productos: results
            })
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al consultar productos.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})

//OBTENER UN PRODUCTO
router.get('/:idProducto', (req, res) => {
    const ID_Producto = req.params.idProducto
    db.query('SELECT ID_Producto, Nombre, Precio, URL_Imagen, Stock FROM productos where ID_Producto = ?',
        { replacements: [ID_Producto] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results == "")
            if (results == "") {
                console.log("entro")
                res.status(404).send({ mensaje: "El producto consultado no existe" })
            }
            else if (results[0].Stock == 0) {
                res.status(202).send({ mensaje: "El producto no se encuentra en stock" })
            }
            else {
                res.status(200).send({
                    mensaje: "Producto consultado",
                    producto: results
                })
            }
        })
        .catch((err) => {
            res.status(400).send({ error: "Ocurrió un error al intentar consultar producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})



//ADD PROD FAV
router.post('/:idUsuario/:idProducto/favs', autorizarUsuario, (req, res) => {
    const ID_Producto = req.params.idProducto;
    const ID_Usuario = req.params.idUsuario
    db.query('SELECT * from productosfavoritos WHERE ID_Usuario = ? AND ID_Producto = ?',
        { replacements: [ID_Usuario, ID_Producto] })
        .then((respuesta) => {
            const [results] = respuesta;
            if (results == "") {
                db.query('INSERT INTO productosfavoritos (ID_Usuario, ID_Producto) VALUES (?, ?)',
                    { replacements: [ID_Usuario, ID_Producto] })
                console.log(results)
                res.status(200).send({ mensaje: "Producto agregado a favoritos!" })
            }
            else {
                res.status(202).send({ mensaje: "El producto ya se encuentra en la lista de favoritos." })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar agregar el producto a favoritos", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})

//OBTENER PRODUCTOS FAVS 
router.get('/:idUsuario/favs', autorizarUsuario, (req, res) => {
    const ID_Usuario = req.params.idUsuario
    db.query('SELECT t1.ID_Producto, Nombre, Precio, URL_Imagen, Stock FROM productos t1 INNER JOIN (SELECT * FROM productosfavoritos WHERE ID_Usuario = ?) t2 on t1.ID_Producto = t2.ID_Producto',
        { replacements: [ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results)
            if (results == "") {
                res.status(202).send({
                    mensaje: "Usted no ha agregado productos favoritos aún."
                })
            }
            else {
                res.status(200).send({
                    mensaje: "Listado de productos favoritos consultado",
                    productos: results
                })
            }
        })
        .catch((err) => {
            res.status(400).send({ error: "Ocurrió un error al intentar consultar productos favoritos.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})

//BORRAR PRODUCTOS FAVS 
router.delete('/:idUsuario/:idProducto/favs', autorizarUsuario, (req, res) => {
    const ID_Usuario = req.params.idUsuario;
    const ID_Producto = req.params.idProducto;
    db.query('DELETE FROM productosfavoritos where ID_Usuario = ? AND ID_Producto = ?',
        { replacements: [ID_Usuario, ID_Producto] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results)
            if (results.affectedRows == 0) {
                res.status(202).send({
                    mensaje: "El producto seleccionado no se encuentra en la lista de favoritos"
                })
            }
            else {
                res.status(200).send({
                    mensaje: "El producto seleccionado se ha eliminado de favoritos"
                })
            }
        })
        .catch((err) => {
            res.status(400).send({ error: "Ocurrió un error al intentar eliminar el producto de la lista de favoritos", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})

//CARGAR PRODUCTO
router.post('/:idUsuario', autorizarUsuario, (req, res) => {
    const { Nombre, Precio, URL_Imagen, Stock } = req.body
    const ID_User = req.params.idUsuario
    db.query('SELECT ID_TipoUsuario FROM usuarios WHERE ID_Usuario = ?',
        { replacements: [ID_User] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results)
            if (results == "") {
                res.status(404).send({ error: "El ID_Usuario utilizado no existe en la base de datos." })
            }
            else if (results[0].ID_TipoUsuario == 1) {
                db.query('SELECT Nombre FROM productos WHERE Nombre = ?',
                    { replacements: [Nombre] })
                    .then((respuesta) => {
                        const [results] = respuesta;
                        if (results == "") {
                            db.query('INSERT INTO productos (Nombre, Precio, URL_Imagen, Stock) VALUES (?, ?, ?, ?)',
                                { replacements: [Nombre, Precio, URL_Imagen, Stock] })
                                .then((respuesta) => {
                                    const [results] = respuesta;
                                    res.status(201).send({ mensaje: "El producto ha sido agregado a la lista" })
                                })
                                .catch((err) => {
                                    console.log(err)
                                    res.status(400).send({ error: "Ocurrió un error al intentar agregar un nuevo producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                                })
                        }
                        else {
                            res.status(202).send({ mensaje: "El producto que intenta cargar, ya se encuentra en el sistema" })
                        }

                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar agregar un nuevo producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else {
                res.status(403).send({ error: "Usted no tiene los permisos suficientes para cargar un producto" })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar agregar un nuevo producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})


//EDITAR PRODUCTO
router.put('/:idUsuario', autorizarUsuario, (req, res) => {
    const { Nombre, Precio, URL_Imagen, Stock } = req.body
    const ID_User = req.params.idUsuario
    db.query('SELECT ID_TipoUsuario FROM usuarios WHERE ID_Usuario = ?',
        { replacements: [ID_User] })
        .then((respuesta) => {
            const [results] = respuesta;
            if (results == "") {
                res.status(404).send({ error: "El ID_Usuario utilizado no existe en la base de datos." })
            }
            else if (results[0].ID_TipoUsuario == 1) {
                db.query('SELECT ID_Producto FROM productos WHERE Nombre = ?',
                    { replacements: [Nombre] })
                    .then((respuesta) => {
                        const [results] = respuesta;
                        console.log(results)
                        const ID_Producto = results[0].ID_Producto
                        if (results != "") {
                            db.query('UPDATE productos SET Nombre = ?, Precio = ?, URL_Imagen = ?, Stock = ? WHERE (ID_Producto = ?)',
                                { replacements: [Nombre, Precio, URL_Imagen, Stock, ID_Producto] })
                                .then((respuesta) => {
                                    const [results] = respuesta;
                                    res.status(200).send({ mensaje: "El producto ha sido editado correctamente" })
                                })
                                .catch((err) => {
                                    console.log(err)
                                    res.status(400).send({ error: "Ocurrió un error al intentar editar el producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                                })
                        }
                        else {
                            res.status(202).send({ mensaje: "El producto que intenta editar, no se encuentra en el sistema" })
                        }
                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar editar el producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else {
                res.status(403).send({ error: "Usted no tiene los permisos suficientes para editar un producto" })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar editar el producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})


//BORRAR PRODUCTO
router.delete('/:idUsuario/:idProducto', autorizarUsuario, (req, res) => {
    const ID_Producto = req.params.idProducto;
    const ID_User = req.params.idUsuario
    db.query('SELECT ID_TipoUsuario FROM usuarios WHERE ID_Usuario = ?',
        { replacements: [ID_User] })
        .then((respuesta) => {
            const [results] = respuesta;
            if (results == "") {
                res.status(404).send({ error: "El ID_Usuario utilizado no existe en la base de datos." })
            }
            else if (results[0].ID_TipoUsuario == 1) {
                db.query('DELETE FROM productos WHERE ID_Producto = ?',
                    { replacements: [ID_Producto] })
                    .then((respuesta) => {
                        const [results] = respuesta;
                        if (results.affectedRows == 0) {
                            res.status(202).send({ mensaje: "El producto especificado no se encuentra en la base" })
                        }
                        else {
                            res.status(200).send({ mensaje: "El producto ha sido borrado correctamente" })
                        }
                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar borrar el producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else {
                res.status(403).send({ error: "Usted no tiene los permisos suficientes para borrar un producto" })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar borrar el producto", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})



module.exports = router;