const router = require('express').Router();
const { db, Sequelize } = require('../../conexionBD');
const autorizarUsuario = require('../middleware/autorizacion')


//HACER PEDIDO 

const hayStock = async (productos, cantidades) => {
    let hayStock = true;
    let cant = [];
    let stock = [];
    for (let x = 0; x < productos.length; x++) {
        [stock] = await db.query('SELECT * FROM productos where ID_Producto = ? and Stock >= ?',
            { replacements: [productos[x], cantidades[x]] })
        console.log(stock[0])
        if (stock[0] == undefined) {
            hayStock = false;
        }
    }
    return hayStock;
}

const updateStock = (productos, cantidades) => {
    for (let x = 0; x < productos.length; x++) {
        let cant;
        if (typeof (cantidades[x]) == "number") {
            cant = cantidades[x]
        }
        else {
            cant = parseInt(cantidades[x].replace(" ", ""))
        }
        db.query('UPDATE productos SET `Stock` = (Stock-(?)) WHERE (`ID_Producto` = ?)',
            { replacements: [cant, productos[x]] })
    }
}

const createPedidoProducto = (productos, cantidades, ID_Pedidol) => {
    for (let x = 0; x < productos.length; x++) {
        let cant = parseInt(cantidades[x].replace(" ", ""))
        console.log(cant)
        db.query('INSERT INTO productospedidos (ID_Pedido, ID_Producto, Cantidad) VALUES (?, ?, ?)',
            { replacements: [ID_Pedido, productos[x], cant] })
    }
}

router.post('/:idUsuario', autorizarUsuario, async function (req, res) {
    const { Direccion, ID_Producto, Cantidad, ID_Pago, Costo_Total } = req.body
    const ID_Usuario = req.params.idUsuario
    const productos = ID_Producto.split(",")
    const cantidades = Cantidad.split(",")
    console.log(productos.length)
    let stockOk = await hayStock(productos, cantidades);
    console.log(stockOk)
    let today = new Date();
    let date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    let dateTime = date + ' ' + time;
    //console.log(dateTime)
    db.query('SELECT * FROM usuarios WHERE ID_Usuario = ?',
        { replacements: [ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results)
            if (results == "") {
                res.status(404).send({ error: "El usuario con el que intenta realizar el pedido, no existe" })
            }
            else {
                if (stockOk == true) {
                    db.query('INSERT INTO pedidos (ID_Usuario, ID_Pago, Fecha, Direccion, Costo_Total, ID_Estado) VALUES (?, ?, ?, ?, ?, ?)',
                        { replacements: [ID_Usuario, ID_Pago, dateTime, Direccion, Costo_Total, 1] })
                        .then((respuesta) => {
                            const [results] = respuesta;
                            console.log(results)
                            if (results != "") {
                                res.status(201).send({
                                    mensaje: 'Pedido creado con éxito',
                                    ID_Pedido: results
                                })
                                createPedidoProducto(productos, cantidades, results);
                                updateStock(productos, cantidades);
                            }
                            else {
                                res.status(400).send({ error: "Ha ocurrido un error en crear el pedido.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                            }
                        })
                        .catch((err) => {
                            console.log(err)
                            res.status(400).send({ error: "Ha ocurrido un error al intentar crear el pedido", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                        })
                }
                else {
                    res.status(202).send({ mensaje: "Uno de los productos solicitados solicitado no tiene stock. Por favor, refresque el sitio." })
                }
            }
        })
})


//OBTENER PEDIDO REALIZADO
router.get('/:idUsuario/:idPedido', autorizarUsuario, (req, res) => {
    const ID_Pedido = req.params.idPedido;
    const ID_Usuario = req.params.idUsuario;
    db.query('SELECT t3.Descripcion as MetodoPago, Fecha, Direccion, Costo_Total, t4.Descripcion as EstadoPedido, t5.Nombre as NombreProducto, Cantidad FROM pedidos t1 inner join (select * from productospedidos) t2 on t1.ID_Pedido = t2.ID_Pedido inner join (select * from metodospago) t3 on t1.ID_Pago = t3.ID_Pago inner join (select * from estadospedidos) t4 on t1.ID_Estado = t4.ID_Estado inner join (select * from productos) t5 on t2.ID_Producto = t5.ID_Producto WHERE t1.ID_Pedido = ? AND t1.ID_Usuario = ?',
        { replacements: [ID_Pedido, ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results)
            if (results == "") {
                res.status(403).send({ mensaje: "El pedido consultado no coincide con el usuario logueado." })
            }
            else {
                res.status(200).send({
                    mensaje: "El pedido fue consultado correctamente",
                    resultado: results
                })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar consultar el pedido", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})


const convertArray = (results) => {
    let prods = [];
    let quantities = [];
    for (x = 0; x < results.length; x++) {
        console.log(results[x].ID_Producto);
        prods.push(results[x].ID_Producto);
        quantities.push(- results[x].Cantidad);
    }
    console.log(prods, quantities)
    updateStock(prods, quantities)
}

//CANCELAR PEDIDO (si se hizo hace menos de 5 minutos)
router.delete('/:idUsuario/:idPedido', autorizarUsuario, (req, res) => {
    const ID_Pedido = req.params.idPedido;
    const ID_Usuario = req.params.idUsuario;
    db.query('SELECT substring_index(Fecha, " ", -1) as Fecha, ID_Estado FROM pedidos where ID_Pedido = ? AND ID_Usuario = ?',
        { replacements: [ID_Pedido, ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results[0].ID_Estado)
            if (results[0].ID_Estado == 0) {
                res.status(202).send({ mensaje: "El pedido ya ha sido cancelado" })
            }
            else {
                let horaPedido = results[0].Fecha;
                let today = new Date();
                let timeNow = today.getHours() * 10000 + today.getMinutes() * 100 + today.getSeconds();
                let horarioInicio = horaPedido.split(':')[0] * 10000 + horaPedido.split(':')[1] * 100 + parseInt(horaPedido.split(':')[2])
                console.log(timeNow, horarioInicio)
                if (timeNow - horarioInicio <= 500) {
                    db.query('UPDATE pedidos SET `ID_Estado` = 0 WHERE (`ID_Pedido` = ?)',
                        { replacements: [ID_Pedido] })
                    db.query('SELECT ID_Producto, Cantidad FROM productospedidos WHERE ID_Pedido = ?',
                        { replacements: [ID_Pedido] })
                        .then((respuesta) => {
                            const [results] = respuesta;
                            convertArray(results);
                        })
                    res.status(200).send({ mensaje: "El pedido ha sido cancelado" })
                }
                else {
                    res.status(403).send({ error: "El pedido fue realizado hace más de 5 minutos, por lo que ya comenzó su preparación." })
                }
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar cancelar el pedido", err })
        })
})

//OBTENER TODOS LOS PEDIDOS (admin)
router.get('/:idUsuario', autorizarUsuario, (req, res) => {
    const ID_Usuario = req.params.idUsuario
    db.query('SELECT ID_TipoUsuario FROM usuarios WHERE ID_Usuario = ?',
        { replacements: [ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            if (results == "") {
                res.status(404).send({ error: "El usuario que intenta obtener la lista de pedidos, no existe" })
            }
            else if (results[0].ID_TipoUsuario == 1) {
                db.query('SELECT ID_Pedido, Email, t3.Descripcion as TipoPago, Fecha, Direccion, Costo_Total, t4.Descripcion as EstadoPedido FROM pedidos t1  INNER JOIN (SELECT ID_Usuario, Email FROM usuarios) t2 ON t1.ID_Usuario = t2.ID_Usuario INNER JOIN (SELECT ID_Pago, Descripcion FROM metodospago) t3 ON t1.ID_Pago = t3.ID_Pago INNER JOIN (SELECT ID_Estado, Descripcion FROM estadospedidos) t4 ON t1.ID_Estado = t4.ID_Estado')
                    .then((respuesta) => {
                        const [results] = respuesta;
                        res.status(200).send({
                            mensaje: "Pedidos consultados",
                            "Lista de pedidos": results
                        })
                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar consultar la lista de pedidos", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else {
                res.status(403).send({ error: "Usted no tiene los permisos suficientes para ver todas las órdenes" })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: err })
        })
})

//CAMBIAR ESTADO DE ORDEN
router.put('/:idUsuario/:idPedido', autorizarUsuario, (req, res) => {
    const ID_Usuario = req.params.idUsuario;
    const ID_Order = req.params.idPedido;
    const { ID_Estado } = req.body;
    db.query('SELECT ID_TipoUsuario FROM usuarios WHERE ID_Usuario = ?',
        { replacements: [ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            if (results == "") {
                res.status(401).send({ error: "El ID_Usuario que intenta actualizar el pedido, no existe" })
            }
            if (results[0].ID_TipoUsuario == 1) {
                db.query('UPDATE pedidos SET `ID_Estado` = ? WHERE (`ID_Pedido` = ?)',
                    { replacements: [ID_Estado, ID_Order] })
                    .then((respuesta) => {
                        const [results] = respuesta;
                        if (results.affectedRows == 0) {
                            res.status(404).send({ error: "El pedido que intenta actualizar no se encuentra en la base de datos" })
                        }
                        else {
                            res.status(200).send({ mensaje: "Pedido actualizado correctamente" })
                        }
                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar actualizar el estado del pedido.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else {
                res.status(403).json({ error: "Usted no tiene los permisos suficientes para editar las órdenes" })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar actualizar el estado del pedido.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})



module.exports = router;