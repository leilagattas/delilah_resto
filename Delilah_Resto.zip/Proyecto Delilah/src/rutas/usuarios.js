const express = require('express');
const server = express();
const router = require('express').Router();
const { db, Sequelize } = require('../../conexionBD');
const autorizarUsuario = require('../middleware/autorizacion')


//REGISTRO
const checkSamePass = (pass1, pass2) => {
    if (pass1 === pass2) {
        return true;
    }
    else {
        return false;
    }
}
router.post('/register', (req, res) => {
    const { nombre, telefono, direccion, email, password, passwordCheck } = req.body
    const passOk = checkSamePass(password, passwordCheck);
    if (passOk) {
        db.query('SELECT * FROM usuarios where Email = ?',
            { replacements: [email] })
            .then((respuesta) => {
                const [results] = respuesta;
                console.log(results)
                if (results == "") {
                    db.query('INSERT INTO usuarios (Nombre_Apellido, Telefono, Direccion, Email, Password) VALUES (?, ?, ?, ?, ?)',
                        { replacements: [nombre, telefono, direccion, email, password] })
                        .then((respuesta) => {
                            const [results] = respuesta;
                            console.log(results)
                            res.status(201).send({ mensaje: 'Usuario creado con éxito' })
                        })
                        .catch((err) => {
                            res.status(400).send({ error: "Ocurrió un error al intentar crear usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                        })
                }
                else {
                    res.status(409).send({ error: "El usuario con ese email, ya existe" })
                }
            })
            .catch((err) => {
                console.log(err)
                res.status(400).send({ error: "Ocurrió un error al intentar crear usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
            })
    }
    else {
        res.status(401).send({ error: "Debe ingresar la misma contraseña" })
    }
})

//LOGIN

router.post('/login', (req, res) => {
    const { email, password } = req.body
    db.query('SELECT email FROM usuarios where Email = ?',
        { replacements: [email] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results)
            if (results != "") {
                db.query('SELECT ID_Usuario, email, password FROM usuarios where Email = ? and password = ?',
                    { replacements: [email, password] })
                    .then((respuesta) => {
                        const [results] = respuesta;

                        if (results != "") {
                            const token = jwt.sign({ email }, server.get('secret_token'), { expiresIn: 525600 })
                            const respuesta = [token]
                            res.status(200).send({
                                mensaje: 'Autenticación correcta',
                                ID_Usuario: results[0].ID_Usuario,
                                token: token
                            })
                        }
                        else {
                            res.status(403).send({ error: "La contraseña ingresada es incorrecta" })
                        }
                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar verificar email y contraseña.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else {
                res.status(401).send({ error: "El email ingresado no posee cuenta." })
            }
        })
        .catch((err) => {
            console.log(err);
            res.status(400).send({ error: "Ocurrió un error al intentar verificar email.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})

//UPDATE USUARIO
router.put('/:idUsuario', autorizarUsuario, (req, res) => {
    const { nombre, telefono, direccion } = req.body
    const ID_Usuario = req.params.idUsuario
    db.query('UPDATE usuarios SET Nombre_Apellido = ?, Telefono = ?, Direccion = ? WHERE (ID_Usuario = ?)',
        { replacements: [nombre, telefono, direccion, ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results.info.split(":", 2)[1].replace(" Changed", "").replace(" ", ""))
            if (results.info.split(":", 2)[1].replace(" Changed", "").replace(" ", "") == 0) {
                res.status(404).send({ error: "El usuario especificado no existe" })
            }
            else {
                res.status(200).send({ mensaje: "Usuario actualizado con éxito" })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar actualizar usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})


//OBTENER TODOS LOS USUARIO
router.get('/:idUsuario', autorizarUsuario, (req, res) => {
    const ID_Usuario = req.params.idUsuario
    db.query('SELECT ID_TipoUsuario FROM usuarios WHERE ID_Usuario = ?',
        { replacements: [ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            if (results == "") {
                res.status(404).send({ error: "Ruta errónea" })
            }
            else if (results[0].ID_TipoUsuario == 1) {
                db.query('SELECT ID_Usuario, Nombre_Apellido, Telefono, Direccion, Email, Descripcion as TipoUsuario FROM usuarios t1 INNER JOIN (SELECT * FROM tiposusuario) t2 ON (t1.ID_TipoUsuario = t2.ID_TipoUsuario)',
                )
                    .then((respuesta) => {
                        const [results] = respuesta;
                        res.status(200).send({ "Usuario(s)": results })
                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar obtener usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else if (results[0].ID_TipoUsuario == 0) {
                db.query('SELECT ID_Usuario, Nombre_Apellido, Telefono, Direccion, Email, Descripcion as TipoUsuario FROM usuarios t1 INNER JOIN (SELECT * FROM tiposusuario) t2 ON (t1.ID_TipoUsuario = t2.ID_TipoUsuario) WHERE ID_Usuario = ?',
                    { replacements: [ID_Usuario] })
                    .then((respuesta) => {
                        const [results] = respuesta;
                        res.status(200).send({ "Usuario": results })
                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar obtener usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else {
                res.status(400).send({ error: "Ocurrió un error al intentar obtener usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar obtener usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})


//BORRAR USUARIO (ADMIN)
router.delete('/:idUsuario/:idUsuarioBorrar', autorizarUsuario, (req, res) => {
    //const { ID_Usuario, Nombre, Email } = req.body
    const ID_User = req.params.idUsuario
    const ID_UserBorrar = req.params.idUsuarioBorrar
    console.log(ID_User, ID_UserBorrar)
    db.query('SELECT ID_TipoUsuario FROM usuarios WHERE ID_Usuario = ?',
        { replacements: [ID_User] })
        .then((respuesta) => {
            const [results] = respuesta;
            //console.log(results[0].ID_TipoUsuario)
            if (results == "") {
                res.status(401).send({ error: "El usuario utilizado para hacer la consulta no existe" })
            }
            else if (results[0].ID_TipoUsuario == 1) {
                db.query('DELETE FROM usuarios WHERE ID_Usuario =?',
                    { replacements: [ID_UserBorrar] })
                    .then((respuesta) => {
                        const [results] = respuesta;
                        console.log(results)
                        if (results.affectedRows == 0) {
                            res.status(404).send({ error: "El usuario especificado para borrar, no existe" })
                        }
                        else {
                            res.status(200).send({ mensaje: "Usuario borrado" })
                        }
                    })
                    .catch((err) => {
                        console.log(err)
                        res.status(400).send({ error: "Ocurrió un error al intentar borrar usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
                    })
            }
            else {
                res.status(403).send({ error: "Usted no tiene los permisos suficientes para acceder a borrar un usuario" })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar borrar usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})

//BORRAR USUARIO (CLIENTE)
router.delete('/:idUsuario', autorizarUsuario, (req, res) => {
    const ID_Usuario = req.params.idUsuario
    db.query('DELETE FROM usuarios WHERE ID_Usuario =?',
        { replacements: [ID_Usuario] })
        .then((respuesta) => {
            const [results] = respuesta;
            console.log(results)
            if (results.affectedRows == 0) {
                res.status(404).send({ mensaje: "No se encontró el usuario especificado" })
            }
            else {
                res.status(200).send({ mensaje: "Usuario borrado" })
            }
        })
        .catch((err) => {
            console.log(err)
            res.status(400).send({ error: "Ocurrió un error al intentar borrar usuario.", tipoError: err.name, errorIdentificado: err.parent.sqlMessage })
        })
})


module.exports = router;