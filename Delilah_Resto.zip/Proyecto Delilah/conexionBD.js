const Sequelize = require('sequelize');

let database = "acamica_proyecto_delilah";
let username = "root";
let passwordDB = "lgattas";

const db = new Sequelize(database, username, passwordDB, {
    host: 'localhost',
    dialect: 'mysql'
});

db.authenticate()
    .then(() => console.log('La conexión fue exitosa'))
    .catch((err) => console.log('Ocurrió un error'))

module.exports = { db, Sequelize };